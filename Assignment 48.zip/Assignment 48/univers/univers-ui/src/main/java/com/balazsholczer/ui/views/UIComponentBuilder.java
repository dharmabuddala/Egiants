package com.balazsholczer.ui.views;

import com.vaadin.ui.Component;

public interface UIComponentBuilder {
	public Component createComponent();
}
