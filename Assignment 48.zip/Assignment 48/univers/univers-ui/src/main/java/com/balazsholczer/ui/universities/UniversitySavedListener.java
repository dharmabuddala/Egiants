package com.balazsholczer.ui.universities;

public interface UniversitySavedListener {
	public void universitySaved();
}
