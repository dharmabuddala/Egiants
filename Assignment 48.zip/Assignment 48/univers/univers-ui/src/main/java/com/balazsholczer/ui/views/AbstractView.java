package com.balazsholczer.ui.views;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;

public class AbstractView implements View {

	public void enter(ViewChangeEvent event) {
		
	}
}
