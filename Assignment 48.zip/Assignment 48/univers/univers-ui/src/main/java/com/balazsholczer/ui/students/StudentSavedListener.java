package com.balazsholczer.ui.students;

public interface StudentSavedListener {
	public void studentSaved();
}
