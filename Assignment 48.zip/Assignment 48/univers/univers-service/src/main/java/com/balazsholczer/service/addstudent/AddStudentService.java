package com.balazsholczer.service.addstudent;

import com.balazsholczer.model.entity.Student;

public interface AddStudentService {
	public void saveStudent(Student student);
}
