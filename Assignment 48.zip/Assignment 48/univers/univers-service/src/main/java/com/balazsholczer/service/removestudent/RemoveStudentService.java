package com.balazsholczer.service.removestudent;

import com.balazsholczer.model.entity.Student;

public interface RemoveStudentService {
	public void removeStudent(Student student);
}
