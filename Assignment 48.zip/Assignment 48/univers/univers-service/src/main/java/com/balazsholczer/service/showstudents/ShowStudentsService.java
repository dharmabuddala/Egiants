package com.balazsholczer.service.showstudents;

import java.util.List;
import com.balazsholczer.model.entity.Student;

public interface ShowStudentsService {
	public List<Student> getAllStudents();
}
