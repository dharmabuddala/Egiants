package com.balazsholczer.service.showuniversities;

import java.util.List;

import com.balazsholczer.model.entity.University;

public interface ShowAllUniversitiesService {
	public List<University> getAllUniversities();
}
