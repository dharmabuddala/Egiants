package com.balazsholczer.service.adduniversity;

import com.balazsholczer.model.entity.University;

public interface AddUniversityService {
	public void addUniversity(University university);
}
