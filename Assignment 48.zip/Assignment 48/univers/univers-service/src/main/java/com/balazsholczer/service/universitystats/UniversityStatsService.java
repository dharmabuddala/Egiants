package com.balazsholczer.service.universitystats;

public interface UniversityStatsService {
	public Integer getStatistics(Integer universityId);
}
